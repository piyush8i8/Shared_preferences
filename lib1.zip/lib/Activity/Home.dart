

import 'package:flutter/material.dart';
import 'package:my_shared_preferences/Activity/Login.dart';
import 'package:my_shared_preferences/model/shared.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override



  Widget build(BuildContext context)

  {

    shared.init();
    String userName= shared.getUserName()??"Error";
    String Email= shared.getUserEmail()??"Error";
    String phone= shared.getUserPhone()??"Error";
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
        backgroundColor: Colors.purple,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text("Welcome to home page" ),
            SizedBox(height: 50,),
            Text("Welcome to home page" ),
            Text( userName ),
            SizedBox(height: 100,),
            Text("Welcome to home page" ),
            Text( Email ),
            SizedBox(height: 100,),
            Text("Welcome to home page" ),
            Text( phone ),
            SizedBox(height: 100,),
            SizedBox(
              height: 60,
              width: 130,
              child: ElevatedButton(
                onPressed: (){

                  shared.obj!.clear();
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));

                },
                child: Text("Logout", style: TextStyle(color: Colors.orange, fontSize: 14),),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
