



import 'package:flutter/material.dart';
import 'package:my_shared_preferences/Activity/Login.dart';
import 'package:my_shared_preferences/model/shared.dart';

class Intro3 extends StatefulWidget {
  const Intro3({super.key});

  @override
  State<Intro3> createState() => _Intro3State();
}

class _Intro3State extends State<Intro3> {
  @override
  Widget build(BuildContext context) {
    shared.init();
    return  Scaffold(
      body: Column(
        children: [
          SizedBox(height: 200,),
          Icon(Icons.access_alarm,size: 80,),
          SizedBox(height: 100,),
          Text("Slide 3"),
          SizedBox( height: 50,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[

              SizedBox(
                height: 60,
                width: 130,
                child: ElevatedButton(

                  onPressed: (){
                    bool? status= shared.getFirstTime()?? false;
                    if(status==false)
                    {
                      shared.setFirstTime(true);
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                    }
                  },
                  child: Text("Finish", style: TextStyle(color: Colors.orange,fontSize: 14),),
                ),
              ),
            ],
          ),

        ],
      ),
    );
  }
}
