



import 'package:flutter/material.dart';
import 'package:my_shared_preferences/Activity/Login.dart';
import 'package:my_shared_preferences/model/shared.dart';

class Intro2 extends StatefulWidget {
  const Intro2({super.key});

  @override
  State<Intro2> createState() => _Intro2State();
}

class _Intro2State extends State<Intro2> {
  @override
  Widget build(BuildContext context) {
    shared.init();
    return  Scaffold(
      body: Column(
        children: [
          SizedBox(height: 200,),
          Icon(Icons.baby_changing_station,size: 80,),
          SizedBox(height: 100,),
          Text("Slide 2"),
          SizedBox( height: 50,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              SizedBox(
                height: 60,
                width: 130,
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Intro2()));

                  },
                  child: Text("Next", style: TextStyle(color: Colors.orange, fontSize: 14),),
                ),
              ),
              SizedBox(
                height: 60,
                width: 130,
                child: ElevatedButton(

                  onPressed: (){
                    bool? status= shared.getFirstTime()?? false;
                    if(status==false)
                    {
                      shared.setFirstTime(true);
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                    }
                  },
                  child: Text("Skip", style: TextStyle(color: Colors.orange,fontSize: 14),),
                ),
              ),
            ],
          ),

        ],
      ),
    );
  }
}
